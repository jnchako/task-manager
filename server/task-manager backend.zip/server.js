const express = require("express");
const cors = require("cors");

const app = express();

const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

const tasks = [
    "Finish Cloud Homework",
    "Study REST APIs",
    "Work on Inbox Simulator"
];

app.get("/", (req, res) => {
    res.send("Student Task Manager Server is running!");
});

app.get("/tasks", (req, res) => {
    res.json({
        status: "success",
        tasks: tasks
    });
});

app.post("/tasks", (req, res) => {
    const newTask = req.body.task;

    if (!newTask) {
        return res.status(400).json({
            status: "error",
            message: "A task is required."
        });
    }

    tasks.push(newTask);

    res.json({
        status: "success",
        message: "Task added successfully.",
        task: newTask
    });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});